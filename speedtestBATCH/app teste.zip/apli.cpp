#include <stdio.h>
#include <iostream>
#include <fstream>
#include <windows.h>


using namespace std;
int contador=0;
int contErros=0;


void CorDoTexto(int i){
    SetConsoleTextAttribute(
            GetStdHandle(STD_OUTPUT_HANDLE),
            FOREGROUND_INTENSITY |
            FOREGROUND_RED |
            FOREGROUND_GREEN |
            FOREGROUND_BLUE
        );

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),i);

}

void getAndPrint(){
    string lineText;
    string conteudo[5];
    ifstream file("TesteRes.txt");


    for (int i = 1; i <= 11 ; i++){

        getline(file , lineText);

        switch(i){
        case 4:
            conteudo[0] = lineText;
            break;

        case 5:
            conteudo[1] = lineText;
            break;

        case 6:
            conteudo[2] = lineText;
            break;

        case 7:
            conteudo[3] = lineText;
            break;

        case 8:
            conteudo[4] = lineText;
            break;

        }

    }
    system("cls");



    if (conteudo[0].size() > 0){
        cout << conteudo[0] << endl ;
        cout << conteudo[1] << endl ;
        cout << conteudo[2] << endl ;
        cout << conteudo[3] << endl ;
        cout << conteudo[4] << endl ;

        contador++;

    }else{
        contErros++;

    }
    CorDoTexto(10);
    cout << "\n" << "Contador: ";
    CorDoTexto(15);
    cout << contador ;


    CorDoTexto(12);
    cout << "  Contador Erros: ";
    CorDoTexto(15);
    cout << contErros << endl ;

}

int main()
{
    int cont=0;
    string id;

    CorDoTexto(15);


    system("speedtest -L");


    cout << "\nEnter ID:  ";
    cin >> id;
    system("cls");

    string speedCommand("speedtest -s ");
    speedCommand += id;
    speedCommand += " > TesteRes.txt";

    CorDoTexto(10);
    cout << "\nIniciando Teste...";
    CorDoTexto(15);



    while(true){
        if(id == "0"){
            system("speedtest > TesteRes.txt");
        }else{

            system(speedCommand.c_str());
        }



        getAndPrint();
    }

    return 0;
}
